<?php
// Teste simples de conectividade
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

echo json_encode([
    "status" => "success",
    "message" => "API simples funcionando!",
    "timestamp" => date('Y-m-d H:i:s')
]);
?>
