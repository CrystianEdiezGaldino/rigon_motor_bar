<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: text/html; charset=UTF-8");

// Incluir arquivos necessários
include_once 'config/database.php';
include_once 'models/Usuario.php';
include_once 'models/Produto.php';

// Instanciar classes
$database = new Database();
$db = $database->getConnection();
$usuario = new Usuario($db);
$produto = new Produto($db);

// Verificar se está logado
$isLoggedIn = isset($_SESSION['user_id']) && $usuario->isLoggedIn();
$isAdmin = $isLoggedIn && $usuario->isAdmin();

// Debug das sessões
if (isset($_POST['debug_session'])) {
    echo "<pre>Debug Sessão: ";
    print_r($_SESSION);
    echo "</pre>";
    exit;
}

// Processar ações
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'login':
                $username = $_POST['username'] ?? '';
                $password = $_POST['password'] ?? '';
                
                // Debug do login
                error_log("Tentativa de login: username=$username");
                
                if ($usuario->login($username, $password)) {
                    $usuario->updateLastLogin($_SESSION['user_id']);
                    $message = 'Login realizado com sucesso!';
                    $isLoggedIn = true;
                    $isAdmin = true;
                    error_log("Login bem-sucedido para: $username");
                } else {
                    $error = 'Usuário ou senha incorretos!';
                    error_log("Login falhou para: $username");
                }
                break;
                
            case 'register':
                $username = $_POST['username'] ?? '';
                $password = $_POST['password'] ?? '';
                $nome = $_POST['nome'] ?? '';
                $email = $_POST['email'] ?? '';
                $role = 'user'; // Usuários novos sempre começam como 'user'
                $ativo = 1;
                
                // Verificar se username já existe
                $existingUser = $usuario->checkUsernameExists($username);
                if ($existingUser) {
                    $error = 'Nome de usuário já existe!';
                } else {
                    // Criar novo usuário
                    $usuario->username = $username;
                    $usuario->password = $password;
                    $usuario->nome = $nome;
                    $usuario->email = $email;
                    $usuario->role = $role;
                    $usuario->ativo = $ativo;
                    
                    if ($usuario->create()) {
                        $message = 'Usuário cadastrado com sucesso! Faça login para continuar.';
                    } else {
                        $error = 'Erro ao cadastrar usuário!';
                    }
                }
                break;
                
            case 'logout':
                session_destroy();
                $isLoggedIn = false;
                $isAdmin = false;
                $message = 'Logout realizado com sucesso!';
                break;
                
            case 'add_product':
                if ($isAdmin) {
                    $nome = $_POST['nome'] ?? '';
                    $descricao = $_POST['descricao'] ?? '';
                    $preco = $_POST['preco'] ?? '';
                    $categoria = $_POST['categoria'] ?? '';
                    $imagem = $_POST['imagem'] ?? '';
                    
                    if ($produto->create($nome, $descricao, $preco, $categoria, $imagem)) {
                        $message = 'Produto adicionado com sucesso!';
                    } else {
                        $error = 'Erro ao adicionar produto!';
                    }
                }
                break;
                
            case 'edit_product':
                if ($isAdmin) {
                    $id = $_POST['id'] ?? '';
                    $nome = $_POST['nome'] ?? '';
                    $descricao = $_POST['descricao'] ?? '';
                    $preco = $_POST['preco'] ?? '';
                    $categoria = $_POST['categoria'] ?? '';
                    $imagem = $_POST['imagem'] ?? '';
                    
                    if ($produto->update($id, $nome, $descricao, $preco, $categoria, $imagem)) {
                        $message = 'Produto atualizado com sucesso!';
                    } else {
                        $error = 'Erro ao atualizar produto!';
                    }
                }
                break;
                
            case 'delete_product':
                if ($isAdmin) {
                    $id = $_POST['id'] ?? '';
                    
                    if ($produto->delete($id)) {
                        $message = 'Produto removido com sucesso!';
                    } else {
                        $error = 'Erro ao remover produto!';
                    }
                }
                break;
        }
    }
}

// Buscar produtos para exibição
$produtos = [];
if ($isAdmin) {
    $stmt = $produto->read();
    if ($stmt) {
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $produtos[] = $row;
        }
    }
}

// Categorias disponíveis
$categorias = ['Cervejas', 'Destilados', 'Drinks', 'Petiscos', 'Refrigerantes', 'Outros'];
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rigon Motor Bar - Administração</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
            color: #ffffff;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 40px;
            padding: 20px;
            background: rgba(244, 95, 10, 0.1);
            border-radius: 15px;
            border: 1px solid rgba(244, 95, 10, 0.3);
        }
        
        .header h1 {
            font-size: 2.5rem;
            color: #F45F0A;
            margin-bottom: 10px;
        }
        
        .header p {
            color: #cccccc;
            font-size: 1.1rem;
        }
        
        .auth-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            max-width: 900px;
            margin: 0 auto 40px;
        }
        
        .login-form, .register-form {
            padding: 30px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #F45F0A;
            font-weight: 600;
        }
        
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.1);
            color: #ffffff;
            font-size: 16px;
        }
        
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: none;
            border-color: #F45F0A;
            box-shadow: 0 0 10px rgba(244, 95, 10, 0.3);
        }
        
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: #F45F0A;
            color: white;
        }
        
        .btn-primary:hover {
            background: #d54d02;
            transform: translateY(-2px);
        }
        
        .btn-success {
            background: #28a745;
            color: white;
        }
        
        .btn-success:hover {
            background: #218838;
            transform: translateY(-2px);
        }
        
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background: #c82333;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .admin-panel {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            padding: 30px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .admin-panel h2 {
            color: #F45F0A;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .product-card {
            background: rgba(255, 255, 255, 0.08);
            border-radius: 12px;
            padding: 20px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
        }
        
        .product-card h3 {
            color: #F45F0A;
            margin-bottom: 10px;
        }
        
        .product-card p {
            color: #cccccc;
            margin-bottom: 8px;
        }
        
        .product-card .price {
            font-size: 1.2rem;
            font-weight: 600;
            color: #28a745;
        }
        
        .product-card .category {
            display: inline-block;
            background: rgba(244, 95, 10, 0.2);
            color: #F45F0A;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.9rem;
            margin-top: 10px;
        }
        
        .add-product-form {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            padding: 30px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 30px;
        }
        
        .add-product-form h3 {
            color: #F45F0A;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .message {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .message.success {
            background: rgba(40, 167, 69, 0.2);
            border: 1px solid rgba(40, 167, 69, 0.5);
            color: #28a745;
        }
        
        .message.error {
            background: rgba(220, 53, 69, 0.2);
            border: 1px solid rgba(220, 53, 69, 0.5);
            color: #dc3545;
        }
        
        .logout-btn {
            position: absolute;
            top: 20px;
            right: 20px;
        }
        
        .toggle-forms {
            text-align: center;
            margin-top: 20px;
        }
        
        .toggle-forms button {
            background: none;
            border: none;
            color: #F45F0A;
            text-decoration: underline;
            cursor: pointer;
            font-size: 0.9rem;
        }
        
        .toggle-forms button:hover {
            color: #d54d02;
        }
        
        /* Modal de Edição */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            overflow: auto;
        }
        
        .modal-content {
            background: linear-gradient(135deg, #2d2d2d 0%, #1a1a1a 100%);
            margin: 5% auto;
            padding: 0;
            border: 1px solid rgba(244, 95, 10, 0.3);
            border-radius: 15px;
            width: 90%;
            max-width: 600px;
            animation: modalSlideIn 0.3s ease-out;
        }
        
        @keyframes modalSlideIn {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .modal-header {
            background: rgba(244, 95, 10, 0.1);
            padding: 20px;
            border-bottom: 1px solid rgba(244, 95, 10, 0.3);
            border-radius: 15px 15px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-header h3 {
            color: #F45F0A;
            margin: 0;
        }
        
        .close {
            color: #F45F0A;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s ease;
        }
        
        .close:hover {
            color: #d54d02;
        }
        
        .modal form {
            padding: 30px;
        }
        
        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            justify-content: flex-end;
        }
        
        .form-actions .btn {
            min-width: 120px;
        }
        
        @media (max-width: 768px) {
            .auth-container {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .products-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 768px) {
            .modal-content {
                width: 95%;
                margin: 10% auto;
            }
            
            .form-actions {
                flex-direction: column;
            }
            
            .form-actions .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🍺 RIGON MOTOR BAR</h1>
            <p>Sistema de Administração</p>
        </div>
        
        <?php if ($message): ?>
            <div class="message success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="message error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if (!$isLoggedIn): ?>
            <!-- Container de Autenticação -->
            <div class="auth-container">
                <!-- Formulário de Login -->
                <div class="login-form">
                    <h2 style="text-align: center; margin-bottom: 30px; color: #F45F0A;">🔐 Login</h2>
                    <form method="POST">
                        <input type="hidden" name="action" value="login">
                        
                        <div class="form-group">
                            <label for="username">Usuário:</label>
                            <input type="text" id="username" name="username" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="password">Senha:</label>
                            <input type="password" id="password" name="password" required>
                        </div>
                        
                        <button type="submit" class="btn btn-primary" style="width: 100%;">Entrar</button>
                    </form>
                    
                    <div style="margin-top: 20px; text-align: center; color: #cccccc; font-size: 0.9rem;">
                        <p><strong>Credenciais padrão:</strong></p>
                        <p>Usuário: <code>admin</code></p>
                        <p>Senha: <code>admin123</code></p>
                    </div>
                    
                    <!-- Botão de debug -->
                    <div style="margin-top: 20px; text-align: center;">
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="debug_session" value="1">
                            <button type="submit" class="btn btn-secondary" style="font-size: 0.8rem; padding: 8px 16px;">
                                🔍 Debug Sessão
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- Formulário de Cadastro -->
                <div class="register-form">
                    <h2 style="text-align: center; margin-bottom: 30px; color: #28a745;">📝 Cadastro</h2>
                    <form method="POST">
                        <input type="hidden" name="action" value="register">
                        
                        <div class="form-group">
                            <label for="reg_username">Nome de Usuário:</label>
                            <input type="text" id="reg_username" name="username" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="reg_nome">Nome Completo:</label>
                            <input type="text" id="reg_nome" name="nome" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="reg_email">E-mail:</label>
                            <input type="email" id="reg_email" name="email" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="reg_password">Senha:</label>
                            <input type="password" id="reg_password" name="password" required minlength="6">
                        </div>
                        
                        <button type="submit" class="btn btn-success" style="width: 100%;">Cadastrar</button>
                    </form>
                    
                    <div style="margin-top: 20px; text-align: center; color: #cccccc; font-size: 0.9rem;">
                        <p><strong>Após o cadastro:</strong></p>
                        <p>• Faça login com suas credenciais</p>
                        <p>• Apenas administradores podem gerenciar produtos</p>
                    </div>
                </div>
            </div>
            
        <?php else: ?>
            <!-- Painel Administrativo -->
            <div style="position: relative;">
                <form method="POST" class="logout-btn">
                    <input type="hidden" name="action" value="logout">
                    <button type="submit" class="btn btn-secondary">🚪 Logout</button>
                </form>
                
                <div class="admin-panel">
                    <h2>🎛️ Painel de Administração</h2>
                    
                    <!-- Formulário para Adicionar Produto -->
                    <div class="add-product-form">
                        <h3>➕ Adicionar Novo Produto</h3>
                        <form method="POST">
                            <input type="hidden" name="action" value="add_product">
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="nome">Nome do Produto:</label>
                                    <input type="text" id="nome" name="nome" required>
                                </div>
                                
                                <div class="form-group">
                                    <label for="categoria">Categoria:</label>
                                    <select id="categoria" name="categoria" required>
                                        <option value="">Selecione uma categoria</option>
                                        <?php foreach ($categorias as $cat): ?>
                                            <option value="<?php echo htmlspecialchars($cat); ?>"><?php echo htmlspecialchars($cat); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="descricao">Descrição:</label>
                                <textarea id="descricao" name="descricao" rows="3" required></textarea>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="preco">Preço (R$):</label>
                                    <input type="number" id="preco" name="preco" step="0.01" min="0" required>
                                </div>
                                
                                <div class="form-group">
                                    <label for="imagem">Nome da Imagem:</label>
                                    <input type="text" id="imagem" name="imagem" placeholder="ex: produto.jpg">
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">➕ Adicionar Produto</button>
                        </form>
                    </div>
                    
                    <!-- Lista de Produtos -->
                    <h3 style="color: #F45F0A; margin-bottom: 20px;">📋 Produtos Cadastrados</h3>
                    
                    <?php if (empty($produtos)): ?>
                        <p style="text-align: center; color: #cccccc; font-style: italic;">Nenhum produto cadastrado.</p>
                    <?php else: ?>
                        <div class="products-grid">
                            <?php foreach ($produtos as $prod): ?>
                                <div class="product-card">
                                    <h3><?php echo htmlspecialchars($prod['nome']); ?></h3>
                                    <p><strong>Descrição:</strong> <?php echo htmlspecialchars($prod['descricao']); ?></p>
                                    <p class="price"><strong>Preço:</strong> R$ <?php echo number_format($prod['preco'], 2, ',', '.'); ?></p>
                                    <p><strong>Categoria:</strong> <span class="category"><?php echo htmlspecialchars($prod['categoria']); ?></span></p>
                                    <?php if ($prod['imagem']): ?>
                                        <p><strong>Imagem:</strong> <?php echo htmlspecialchars($prod['imagem']); ?></p>
                                    <?php endif; ?>
                                    <p><strong>Status:</strong> <?php echo $prod['ativo'] ? '✅ Ativo' : '❌ Inativo'; ?></p>
                                    
                                    <div style="margin-top: 15px; display: flex; gap: 10px;">
                                        <button onclick="editProduct(<?php echo $prod['id']; ?>)" class="btn btn-secondary" style="flex: 1;">✏️ Editar</button>
                                        <form method="POST" style="flex: 1;" onsubmit="return confirm('Tem certeza que deseja remover este produto?')">
                                            <input type="hidden" name="action" value="delete_product">
                                            <input type="hidden" name="id" value="<?php echo $prod['id']; ?>">
                                            <button type="submit" class="btn btn-danger" style="width: 100%;">🗑️ Remover</button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Modal de Edição -->
    <div id="editModal" class="modal" style="display: none;">
        <div class="modal-content">
            <div class="modal-header">
                <h3>✏️ Editar Produto</h3>
                <span class="close" onclick="closeEditModal()">&times;</span>
            </div>
            <form method="POST" id="editForm">
                <input type="hidden" name="action" value="edit_product">
                <input type="hidden" name="id" id="edit_id">
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_nome">Nome do Produto:</label>
                        <input type="text" id="edit_nome" name="nome" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_categoria">Categoria:</label>
                        <select id="edit_categoria" name="categoria" required>
                            <option value="">Selecione uma categoria</option>
                            <?php foreach ($categorias as $cat): ?>
                                <option value="<?php echo htmlspecialchars($cat); ?>"><?php echo htmlspecialchars($cat); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="edit_descricao">Descrição:</label>
                    <textarea id="edit_descricao" name="descricao" rows="3" required></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_preco">Preço (R$):</label>
                        <input type="number" id="edit_preco" name="preco" step="0.01" min="0" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_imagem">Nome da Imagem:</label>
                        <input type="text" id="edit_imagem" name="imagem" placeholder="ex: produto.jpg">
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">💾 Salvar Alterações</button>
                    <button type="button" class="btn btn-secondary" onclick="closeEditModal()">❌ Cancelar</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        function editProduct(id) {
            // Buscar dados do produto via AJAX
            fetch('get-product.php?id=' + id)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const produto = data.produto;
                        
                        // Preencher o formulário
                        document.getElementById('edit_id').value = produto.id;
                        document.getElementById('edit_nome').value = produto.nome;
                        document.getElementById('edit_descricao').value = produto.descricao;
                        document.getElementById('edit_preco').value = produto.preco;
                        document.getElementById('edit_categoria').value = produto.categoria;
                        document.getElementById('edit_imagem').value = produto.imagem || '';
                        
                        // Mostrar o modal
                        document.getElementById('editModal').style.display = 'block';
                    } else {
                        alert('Erro ao carregar dados do produto: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Erro:', error);
                    alert('Erro ao carregar dados do produto');
                });
        }
        
        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }
        
        // Fechar modal ao clicar fora dele
        window.onclick = function(event) {
            const modal = document.getElementById('editModal');
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
    </script>
</body>
</html>
