<?php
// Arquivo de teste para verificar se a API está acessível
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

echo json_encode([
    "status" => "success",
    "message" => "API está funcionando!",
    "timestamp" => date('Y-m-d H:i:s'),
    "php_version" => PHP_VERSION,
    "server" => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
    "method" => $_SERVER['REQUEST_METHOD'],
    "url" => $_SERVER['REQUEST_URI'],
    "document_root" => $_SERVER['DOCUMENT_ROOT'],
    "script_name" => $_SERVER['SCRIPT_NAME'],
    "request_uri" => $_SERVER['REQUEST_URI']
]);
?>
